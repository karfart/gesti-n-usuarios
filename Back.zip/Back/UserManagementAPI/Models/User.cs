﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace UserManagementAPI.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string Nombre { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required]
        [JsonPropertyName("passwordHash")]   // ✅ Coincide con Angular
        public string PasswordHash { get; set; }
    }
}
