﻿using BCrypt.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserManagementAPI.Data;
using UserManagementAPI.Models;
using UserManagementAPI.Services;

namespace UserManagementAPI.Controllers
{
    [ApiController]
    [Route("api")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;   // ✅ Cambiado a AppDbContext
        private readonly JwtService _jwt;

        public AuthController(AppDbContext context, JwtService jwt)   // ✅ Constructor actualizado
        {
            _context = context;
            _jwt = jwt;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            Console.WriteLine(">>> Register llamado");
            Console.WriteLine($"Email: {user.Email}");
            Console.WriteLine($"Password recibido: {user.PasswordHash}");

            // ✅ Generar hash antes de guardar
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(user.PasswordHash);
            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Usuario registrado" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User login)
        {
            Console.WriteLine(">>> Login llamado");
            Console.WriteLine($"Email recibido: {login.Email}");
            Console.WriteLine($"Password recibido: {login.PasswordHash}");

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == login.Email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(login.PasswordHash, user.PasswordHash))
            {
                Console.WriteLine(">>> Credenciales inválidas");
                return Unauthorized("Credenciales inválidas");
            }

            var token = _jwt.GenerateToken(user);
            Console.WriteLine(">>> Login OK, token generado");
            return Ok(new { token });
        }
    }
}

