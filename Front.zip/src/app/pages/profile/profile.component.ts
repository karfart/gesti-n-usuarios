import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {
  user: any = {};
  userId: number | null = null;

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.userId = this.authService.getUserIdFromToken(); // ✅ Ahora obtiene el ID real desde el token
    console.log('userId obtenido del token:', this.userId);

    if (this.userId) {
      this.userService.getUser(this.userId).subscribe({
        next: (res) => this.user = res,
        error: (err) => console.error('Error cargando perfil', err)
      });
    }
  }

  update() {
    if (!this.userId) {
      console.error('userId es null o undefined. Verifica que el token tenga "sub".');
      return;
    }

    const payload: any = {
      id: this.userId,
      nombre: this.user.nombre,
      email: this.user.email
    };

    if (this.user.passwordHash) {
      payload.passwordHash = this.user.passwordHash;
    }

    this.userService.updateUser(this.userId, payload).subscribe({
      next: () => alert('Perfil actualizado'),
      error: (err) => console.error('Error al actualizar:', err)
    });
  }



  delete() {
    if (this.userId && confirm('¿Seguro que quieres eliminar tu cuenta?')) {
      this.userService.deleteUser(this.userId).subscribe({
        next: () => {
          this.authService.logout();
          this.router.navigate(['/register']);
        },
        error: (err) => console.error('Error al eliminar cuenta', err)
      });
    }
  }
}
