import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  nombre = '';
  email = '';
  password = '';
  mensajeExito = '';   // ✅ Variable para mostrar mensaje

  constructor(private auth: AuthService, private router: Router) {}

  register() {
    const payload = {
      id: 0,
      nombre: this.nombre,
      email: this.email,
      passwordHash: this.password
    };

    this.auth.register(payload).subscribe({
      next: () => {
        this.mensajeExito = '✅ Registro completado satisfactoriamente.'; // ✅ Mensaje de éxito
        setTimeout(() => {
          this.router.navigate(['/login']); // ✅ Redirige después de 2 segundos
        }, 2000);
      },
      error: err => console.error('Error en registro:', err)
    });
  }
}
