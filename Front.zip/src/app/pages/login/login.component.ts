import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  email = '';
  password = '';
  errorMessage = '';

  constructor(private auth: AuthService, private router: Router) {}

login() {
    this.errorMessage = ''; // Resetear mensaje
    this.auth.login({
      id: 0,
      nombre: 'LoginUser',
      email: this.email,
      passwordHash: this.password
    }).subscribe({
      next: (res: any) => {
        this.auth.saveToken(res.token);
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        console.error('Error de login', err);
        if (err.status === 400 || err.status === 401) {
          this.errorMessage = 'Usuario o contraseña incorrectos.';
        } else {
          this.errorMessage = 'Error en el servidor, intenta más tarde.';
        }
      }
    });
  }


}
