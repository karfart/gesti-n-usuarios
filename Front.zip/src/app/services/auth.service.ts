import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { jwtDecode } from 'jwt-decode';
import { HttpHeaders } from '@angular/common/http';


interface JwtPayload {
  sub: string; // Si tu API usa "sub" como ID
  name?: string;
  email?: string;
  [key: string]: any;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://localhost:7005/api';

  constructor(private http: HttpClient) {}

  
  register(data: any): Observable<any> {
  return this.http.post(`${this.apiUrl}/register`, data, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  });
  }

  login(data: any): Observable<any> {
  return this.http.post(`${this.apiUrl}/login`, data, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  });
  }

  logout() {
    localStorage.removeItem('token');
  }

  saveToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getUserIdFromToken(): number | null {
    const token = localStorage.getItem('token');
    if (!token) return null;

    try {
      const decoded = jwtDecode<JwtPayload>(token);
      console.log('Token decodificado:', decoded);
      return decoded.sub ? parseInt(decoded.sub, 10) : null;
    } catch (err) {
      console.error('Error decodificando token', err);
      return null;
    }
  }
}
